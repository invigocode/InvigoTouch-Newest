# Design Direction: Swiss International Style (Dark Mode)

## Design Philosophy
**"Onyx & Alabaster"**: A design language built on objective clarity, extreme contrast, and strict grid systems. The goal is to convey confidence and sophistication through a "less is more" approach.

## Core Principles
1.  **Objective Clarity**: Information is presented without decoration. The content *is* the design.
2.  **Asymmetry**: Dynamic, off-center layouts that guide the eye and create tension.
3.  **Negative Space**: Massive amounts of black space to give weight to the text.
4.  **Scale Contrast**: Extreme difference in font sizes—massive headlines vs. tiny, precise functional text.

## Visual Language
*   **Color Palette**:
    *   Background: Pure Black (`#000000`)
    *   Text: Off-White (`#F0F0F0`)
    *   Accent: Electric Blue (`#2563EB`) - Used *very* sparingly for primary actions only.
    *   Borders/Lines: Dark Gray (`#333333`)
*   **Typography**:
    *   **Display**: `Inter` (Tight tracking, Bold/Black weights) or `Helvetica Now Display` equivalent.
    *   **Body**: `Inter` (Neutral, legible).
*   **Layout**:
    *   12-column grid.
    *   Horizontal rule lines separating sections.
    *   No vertical borders.
    *   Content often aligned to the right or center-right, leaving the left open.

## Signature Elements
1.  **Huge Typography**: Headlines that span the full width or take up 50% of the screen height.
2.  **Rule Lines**: Crisp horizontal lines that structure the page.
3.  **Minimal Iconography**: Simple, stroke-based icons.

## Interaction & Animation
*   **Interaction**: Subtle underlines, precise color shifts. No bouncing.
*   **Animation**: Elements slide in from the bottom with a crisp easing curve (`cubic-bezier(0.16, 1, 0.3, 1)`).

## Implementation Notes
*   Use `border-t` or `border-b` for section dividers.
*   Ensure high contrast for accessibility.
*   Use `tracking-tighter` for large headlines.
