import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Placeholder({ title }: { title: string }) {
  return (
    <Layout>
      <div className="container mx-auto px-6 py-32 min-h-[80vh] flex flex-col justify-center">
        <h1 className="text-6xl md:text-9xl font-bold tracking-tighter mb-8">
          {title.toUpperCase()}
        </h1>
        <div className="h-1 w-32 bg-primary mb-12"></div>
        <p className="text-2xl text-muted-foreground max-w-2xl mb-12">
          This page is currently under construction as part of the redesign.
        </p>
        <Link href="/">
          <Button size="lg" className="rounded-none w-fit bg-foreground text-background hover:bg-primary hover:text-white transition-all">
            Return Home
          </Button>
        </Link>
      </div>
    </Layout>
  );
}
