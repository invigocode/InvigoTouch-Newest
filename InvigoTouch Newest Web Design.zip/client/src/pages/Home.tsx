import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Terminal, Zap, Shield, BarChart3 } from "lucide-react";
import { Link } from "wouter";
import Counter from "@/components/Counter";

export default function Home() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center border-b border-border overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-8">
              <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-[0.9] mb-8">
                INVIGORATE<br />
                YOUR<br />
                <span className="text-muted-foreground">BUSINESS.</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-12 leading-relaxed">
                We transform operations with intelligent automation, custom AI agents, and data-driven solutions that deliver measurable ROI.
              </p>
              <div className="flex flex-col sm:flex-row gap-6">
                <Link href="/contact">
                  <Button size="lg" className="rounded-none text-lg px-8 py-6 bg-foreground text-background hover:bg-primary hover:text-white transition-all">
                    Start Transformation <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/solutions">
                  <Button size="lg" className="rounded-none text-lg px-8 py-6 bg-foreground text-background hover:bg-primary hover:text-white transition-all">
                    Explore Solutions
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Abstract Visual Element */}
            <div className="hidden lg:block lg:col-span-4 relative h-full min-h-[400px]">
              <div className="absolute inset-0 border-l border-border pl-12 flex flex-col justify-between py-12">
                <div className="space-y-2">
                  <div className="text-6xl font-bold">
                    <Counter value={95} suffix="%" />
                  </div>
                  <div className="text-sm uppercase tracking-widest text-muted-foreground">Task Automation</div>
                </div>
                <div className="space-y-2">
                  <div className="text-6xl font-bold">
                    <Counter value={3} suffix="x" />
                  </div>
                  <div className="text-sm uppercase tracking-widest text-muted-foreground">Faster Delivery</div>
                </div>
                <div className="space-y-2">
                  <div className="text-6xl font-bold">
                    <Counter value={50} suffix="+" />
                  </div>
                  <div className="text-sm uppercase tracking-widest text-muted-foreground">Clients Served</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Marquee (Simulated) */}
      <section className="py-12 border-b border-border bg-secondary/20">
        <div className="container mx-auto px-6">
          <p className="text-sm uppercase tracking-widest text-muted-foreground mb-8">Trusted by Industry Leaders</p>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
            {/* Placeholders for logos - using text for Swiss style minimalism */}
            <div className="text-xl font-bold tracking-tighter">TechCorp</div>
            <div className="text-xl font-bold tracking-tighter">InnovateLabs</div>
            <div className="text-xl font-bold tracking-tighter">DataStream</div>
            <div className="text-xl font-bold tracking-tighter">CloudFirst</div>
            <div className="text-xl font-bold tracking-tighter">NextGen AI</div>
            <div className="text-xl font-bold tracking-tighter">ScaleUp</div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-32 border-b border-border">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            <div className="lg:col-span-4">
              <h2 className="text-5xl font-bold tracking-tighter mb-6 sticky top-32">
                AI SOLUTIONS<br />
                THAT<br />
                TRANSFORM
              </h2>
            </div>
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
              <ServiceCard 
                icon={<Terminal className="h-8 w-8" />}
                title="Custom AI Agents"
                description="Deploy intelligent agents that handle customer support, sales, and operations 24/7 with human-like understanding."
              />
              <ServiceCard 
                icon={<Zap className="h-8 w-8" />}
                title="Process Automation"
                description="Streamline workflows and eliminate manual tasks with AI-powered automation that scales with your business."
              />
              <ServiceCard 
                icon={<BarChart3 className="h-8 w-8" />}
                title="Predictive Analytics"
                description="Make data-driven decisions with AI models that forecast trends, identify opportunities, and mitigate risks."
              />
              <ServiceCard 
                icon={<Shield className="h-8 w-8" />}
                title="AI Security"
                description="Enterprise-grade security with full compliance for GDPR, HIPAA, and industry-specific regulations."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section className="py-32 bg-foreground text-background">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl md:text-7xl font-bold tracking-tighter mb-8 leading-tight">
                WE DON'T JUST<br />
                BUILD AI.<br />
                WE BUILD<br />
                <span className="text-primary">RESULTS.</span>
              </h2>
              <Link href="/why-us">
                <Button size="lg" className="rounded-none text-lg px-8 py-6 bg-background text-foreground hover:bg-primary hover:text-white transition-all mt-8">
                  Our Methodology
                </Button>
              </Link>
            </div>
            <div className="space-y-8">
              <FeatureRow title="Rapid Deployment" description="Go from concept to production in weeks, not months." />
              <FeatureRow title="Measurable ROI" description="Every solution includes clear KPIs and ROI tracking." />
              <FeatureRow title="Enterprise Security" description="SOC 2 compliant infrastructure with end-to-end encryption." />
              <FeatureRow title="Dedicated Support" description="Your success team includes AI specialists and strategists." />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 border-b border-border">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-5xl md:text-8xl font-bold tracking-tighter mb-12">
            READY TO<br />INVIGORATE?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-12">
            Join 50+ companies already transforming their operations with InvigoTouch.
          </p>
          <Link href="/contact">
            <Button size="lg" className="rounded-none text-xl px-12 py-8 bg-foreground text-background hover:bg-primary hover:text-white transition-all">
              Book Your Free Consultation
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
}

function ServiceCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="group border-t border-border pt-8 hover:border-primary transition-colors duration-300">
      <div className="mb-6 text-muted-foreground group-hover:text-primary transition-colors">{icon}</div>
      <h3 className="text-2xl font-bold tracking-tight mb-4">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}

function FeatureRow({ title, description }: { title: string, description: string }) {
  return (
    <div className="flex gap-6 items-start border-b border-black/10 pb-8 last:border-0">
      <CheckCircle2 className="h-6 w-6 mt-1 flex-shrink-0" />
      <div>
        <h4 className="text-xl font-bold mb-2">{title}</h4>
        <p className="opacity-80">{description}</p>
      </div>
    </div>
  );
}
